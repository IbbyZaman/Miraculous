package uk.co.miraculoushub.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.Source;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class MainActivity extends Activity {
 private static final String HOST="https://video.miraculoushub.co.uk";
 private static final String CATALOG="https://upload.miraculoushub.co.uk/catalog";
 private static final String POSTER="https://miraculoushub.co.uk/main-season7-poster.png";
 private static final int BG=0xff0a0712, PANEL=0xff181328, PINK=0xffff2d55, MUTED=0xffa9a6bd;
 private final Handler handler=new Handler(Looper.getMainLooper());
 private final ArrayList<JSONObject> bundled=new ArrayList<>(), episodes=new ArrayList<>(), trailers=new ArrayList<>();
 private LinearLayout menu, content;
 private TextView networkStatus;
 private ScrollView mainScroll;
 private String page="Home", selectedAnime="";
 private int selectedSeason=7;
 private boolean updating=false;
 private String catalogError="";
 private long lastUpdateCheck=0;
 private long lastLibrarySync=0;
 private final Runnable liveRefresh=new Runnable(){@Override public void run(){refresh();handler.postDelayed(this,120000);}};

 @Override public void onCreate(Bundle saved){
   super.onCreate(saved);immersive();loadBundled();showStartupSplash();
 }
 private void showStartupSplash(){
   FrameLayout root=new FrameLayout(this);root.setBackgroundColor(0xff0a0712);setContentView(root);
   ImageView heroes=new ImageView(this);heroes.setScaleType(ImageView.ScaleType.CENTER_CROP);
   root.addView(heroes,new FrameLayout.LayoutParams(-1,-1));
   Glide.with(this).load(POSTER).centerCrop().into(heroes);
   View shade=new View(this);shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
     new int[]{0x660a0712,0xff0a0712}));root.addView(shade,new FrameLayout.LayoutParams(-1,-1));
   LinearLayout panel=vertical();panel.setGravity(Gravity.CENTER);panel.setPadding(dp(40),dp(30),dp(40),dp(30));
   root.addView(panel,new FrameLayout.LayoutParams(-1,-1));
   TextView logo=text("MIRACULOUS HUB",28,true,Color.WHITE);logo.setGravity(Gravity.CENTER);panel.addView(logo);
   space(panel,12);
   ProgressBar spinner=new ProgressBar(this);panel.addView(spinner,new LinearLayout.LayoutParams(dp(42),dp(42)));
   space(panel,12);
   TextView status=text("Connecting to MiraculousHub…",17,false,0xffe0e0e8);status.setGravity(Gravity.CENTER);panel.addView(status);
   TextView error=text("The MiraculousHub server could not be reached.",17,true,Color.WHITE);
   error.setGravity(Gravity.CENTER);error.setVisibility(View.GONE);panel.addView(error);
   TextView retry=text("↻  Restart / Try Again",16,true,Color.WHITE);retry.setGravity(Gravity.CENTER);
   retry.setPadding(dp(24),dp(14),dp(24),dp(14));retry.setBackground(bg(PINK,10));retry.setFocusable(true);retry.setVisibility(View.GONE);
   LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-2,-2);rp.topMargin=dp(18);panel.addView(retry,rp);
   retry.setOnClickListener(v->showStartupSplash());
   new Thread(()->{
     boolean online=false;String issue="Server is offline or not responding.";
     try{
       HttpURLConnection conn=(HttpURLConnection)new URL(HOST).openConnection();
       conn.setConnectTimeout(7000);conn.setReadTimeout(7000);conn.setRequestMethod("GET");
       int code=conn.getResponseCode();online=code>=200&&code<500;conn.disconnect();
       if(!online)issue="Server returned HTTP "+code+".";
     }catch(Exception ex){issue="Check your internet connection and try again.";}
     final boolean connected=online;final String message=issue;
     runOnUiThread(()->{
       if(isFinishing())return;
       if(connected){render();refresh();checkAppUpdates();}
       else{
         spinner.setVisibility(View.GONE);status.setText(message);error.setVisibility(View.VISIBLE);
         retry.setVisibility(View.VISIBLE);retry.requestFocus();
       }
     });
   }).start();
 }
 private void immersive(){getWindow().getDecorView().setSystemUiVisibility(
   View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|
   View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
 }
 private int dp(float n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
 private GradientDrawable bg(int color,int r){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(r));return d;}
 private GradientDrawable blend(int start,int end,int r){
   GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{start,end});d.setCornerRadius(dp(r));return d;
 }
 private TextView text(String val,int size,boolean bold,int color){
   TextView v=new TextView(this);v.setText(val);v.setTextSize(size);v.setTextColor(color);
   if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;
 }
 private TextView text(String val,int size,boolean bold){return text(val,size,bold,-1);}
 private LinearLayout vertical(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
 private void space(LinearLayout parent,int n){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(dp(1),dp(n)));}
 private void artwork(ImageView view,String url){
   view.setBackground(blend(0xff38263f,0xff151923,13));
   if(url==null||url.isEmpty())return;
   String resolved=url.startsWith("https://")?url:"https://miraculoushub.co.uk/"+url.replaceFirst("^/","");
   if(resolved.startsWith("https://"))Glide.with(this).load(resolved).centerCrop().into(view);
 }
 private void loadBundled(){
   try(InputStream in=getAssets().open("episodes.json")){
     ByteArrayOutputStream data=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int n;
     while((n=in.read(buffer))!=-1)data.write(buffer,0,n);
     JSONArray all=new JSONArray(data.toString("UTF-8"));
     for(int i=0;i<all.length();i++){JSONObject item=all.optJSONObject(i);if(item!=null)bundled.add(item);}
     episodes.addAll(bundled);
   }catch(Exception e){android.util.Log.e("MiraculousTV","Missing bundled catalogue",e);}
 }
 private String getText(String endpoint,int maxBytes) throws Exception {
   HttpURLConnection conn=(HttpURLConnection)new URL(endpoint).openConnection();
   conn.setConnectTimeout(8500);conn.setReadTimeout(8500);
   conn.setRequestProperty("Accept","application/json, text/javascript");
   conn.setRequestProperty("Cache-Control","no-cache");
   conn.setRequestProperty("User-Agent","MiraculousHubTV/1.0");
   if(conn.getResponseCode()!=200){int code=conn.getResponseCode();conn.disconnect();throw new IOException("HTTP "+code);}
   ByteArrayOutputStream out=new ByteArrayOutputStream();
   try(InputStream in=conn.getInputStream()){
     byte[] b=new byte[8192];int n;
     while((n=in.read(b))!=-1){
       if(out.size()+n>maxBytes)throw new IOException("Response too large");
       out.write(b,0,n);
     }
   }finally{conn.disconnect();}
   return out.toString("UTF-8");
 }
 private void refresh(){
   if(updating)return;updating=true;lastLibrarySync=System.currentTimeMillis();
   new Thread(()->{
     LinkedHashMap<String,JSONObject> map=new LinkedHashMap<>();
     for(JSONObject row:bundled)map.put(row.optString("code"),row);
     String failure="";
     ArrayList<JSONObject> ts=new ArrayList<>();
     try{
       // Fetch the site's own catalogue first: the APK's bundled fallback can get old.
       String script=getText("https://miraculoushub.co.uk/data.js",1400000);
       int marker=script.indexOf("window.MH_EPISODES"),open=script.indexOf('[',marker);
       int close=script.indexOf("];",open);
       if(marker<0||open<0||close<0)throw new IOException("Website episode data not found");
       JSONArray site=new JSONArray(script.substring(open,close+1));
       LinkedHashMap<String,JSONObject> fromWebsite=new LinkedHashMap<>();
       for(int i=0;i<site.length();i++){
         JSONObject row=site.optJSONObject(i);if(row==null)continue;
         int season=row.optInt("season"),ep=row.optInt("episode");
         if(season<1||season>7||ep<1||ep>99)continue;
         String code=String.format(Locale.US,"S%02dE%02d",season,ep);
         if(row.optBoolean("available",true))fromWebsite.put(code,row);
       }
       if(!fromWebsite.isEmpty())map=fromWebsite;
     }catch(Exception ex){failure="Website library: "+ex.getMessage();}
     try{
       // Same upload R2 catalog used by upload.html and catalog.js on the website.
       JSONArray rows=new JSONObject(getText(CATALOG,2000000)).getJSONArray("entries");
       for(int i=0;i<rows.length();i++){
         JSONObject row=rows.optJSONObject(i);if(row==null)continue;
         if("trailer".equals(row.optString("kind"))){
           if(row.optString("id").matches("[a-z0-9][a-z0-9-]{0,79}"))ts.add(row);
           continue;
         }
         if(!"episode".equals(row.optString("kind")))continue;
         int season=row.optInt("season"),ep=row.optInt("episode");
         if(season<1||season>7||ep<1||ep>99)continue;
         String code=String.format(Locale.US,"S%02dE%02d",season,ep);
         if(!row.optBoolean("available",true)){map.remove(code);continue;}
         JSONObject copy=new JSONObject(row.toString());copy.put("code",code);
         copy.put("videoPath","/video/"+code.toLowerCase(Locale.US));
         // Only the thumbnail explicitly saved in upload.html is applied.
         map.put(code,copy);
       }
     }catch(Exception ex){failure+=(failure.isEmpty()?"":" • ")+"Upload catalogue: "+ex.getMessage();}
     ArrayList<JSONObject> updated=new ArrayList<>(map.values());
     updated.sort((x,y)->{int c=Integer.compare(x.optInt("season"),y.optInt("season"));return c!=0?c:Integer.compare(x.optInt("episode"),y.optInt("episode"));});
     String problem=failure;
     handler.post(()->{
       updating=false;catalogError=problem;
       episodes.clear();episodes.addAll(updated);
       trailers.clear();trailers.addAll(ts);
       render();
       if(networkStatus!=null)networkStatus.setText(problem.isEmpty()?"● WEBSITE LIBRARY LIVE":"● WEBSITE SYNC PARTIAL");
     });
   }).start();
 }
 private ImageView heroImg;
 private TextView heroKicker,heroTitle,heroMeta;
 private JSONObject heroItem;
 private Runnable heroSwapRun;
 private int screenW(){return getResources().getDisplayMetrics().widthPixels;}
 private GradientDrawable ring(int r){GradientDrawable d=new GradientDrawable();d.setColor(0x00000000);d.setCornerRadius(dp(r));d.setStroke(dp(3),0xffffffff);return d;}
 private void addGap(LinearLayout parent,View v,int left){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.leftMargin=dp(left);parent.addView(v,lp);}
 private TextView pill(String label,int size,boolean solid,Runnable action){
   TextView v=text(label,size,true,solid?0xff120d20:Color.WHITE);
   v.setGravity(Gravity.CENTER);v.setFocusable(true);v.setClickable(true);
   v.setPadding(dp(28),dp(13),dp(28),dp(13));
   v.setBackground(bg(solid?0xfff6f3ff:0x552a2142,30));
   v.setOnFocusChangeListener((x,f)->{
     v.setBackground(bg(f?(solid?0xffffffff:0xff6a54a0):(solid?0xfff6f3ff:0x552a2142),30));
     v.animate().scaleX(f?1.08f:1).scaleY(f?1.08f:1).setDuration(130).start();
   });
   v.setOnClickListener(x->action.run());
   return v;
 }
 private String thumb(JSONObject item){
   String t=item.optString("thumbnail","");
   if(t.isEmpty()&&item.optInt("season")==7)t=POSTER;
   if(t.isEmpty()&&item.optString("videoPath","").contains("/anime/")){
     String[] sg=item.optString("videoPath").split("/");if(sg.length>3)t=cover(sg[3]);
   }
   return t;
 }
 private String metaFor(JSONObject item){
   if("trailer".equals(item.optString("kind")))return "TRAILER   •   PREVIEW";
   int s=item.optInt("season"),e=item.optInt("episode");
   if(s>0&&e>0)return "SEASON "+s+"   •   EPISODE "+e;
   return item.optString("code","");
 }
 private String urlFor(JSONObject item){
   if("trailer".equals(item.optString("kind")))return HOST+"/video/trailer/"+item.optString("id");
   return HOST+item.optString("videoPath");
 }
 private void open(JSONObject item){
   String name=item.optString("title","Episode");
   boolean trailer="trailer".equals(item.optString("kind"));
   String url=urlFor(item);
   if(!trailer)getPreferences(0).edit().putString("recentUrl",url).putString("recentTitle",name)
     .putString("recentKey",cloudKeyForItem(item)).putInt("recentSeason",item.optInt("season"))
     .putInt("recentEpisode",item.optInt("episode")).apply();
   launch(url,name,item);
 }
 private void setHero(JSONObject item){
   if(heroTitle==null||item==heroItem)return;
   heroItem=item;
   handler.removeCallbacks(heroSwapRun);
   heroSwapRun=()->{
     if(heroTitle==null||heroItem==null)return;
     heroKicker.setText(metaFor(heroItem));
     heroTitle.setText(heroItem.optString("title","Episode"));
     artwork(heroImg,thumb(heroItem));
   };
   handler.postDelayed(heroSwapRun,220);
 }
 private void render(){
   handler.removeCallbacks(heroSwapRun);
   if(!java.util.Arrays.asList("Home","Episodes","Upcoming","Anime","Trailers","Continue","Live").contains(page))page="Home";
   FrameLayout root=new FrameLayout(this);root.setBackgroundColor(BG);setContentView(root);
   boolean onHome="Home".equals(page);
   heroImg=null;heroTitle=null;heroKicker=null;heroMeta=null;heroItem=null;networkStatus=null;
   if(onHome){
     heroImg=new ImageView(this);heroImg.setScaleType(ImageView.ScaleType.CENTER_CROP);
     root.addView(heroImg,new FrameLayout.LayoutParams(-1,dp(480),Gravity.TOP));
     artwork(heroImg,POSTER);
     View side=new View(this);
     side.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xff0a0712,0xe60a0712,0x330a0712,0x000a0712}));
     root.addView(side,new FrameLayout.LayoutParams(-1,dp(480),Gravity.TOP));
     View floor=new View(this);
     floor.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x000a0712,0xff0a0712}));
     root.addView(floor,new FrameLayout.LayoutParams(-1,dp(480),Gravity.TOP));
   }
   mainScroll=new ScrollView(this);mainScroll.setVerticalScrollBarEnabled(false);
   mainScroll.setClipChildren(false);mainScroll.setClipToPadding(false);
   root.addView(mainScroll,new FrameLayout.LayoutParams(-1,-1));
   content=vertical();content.setClipChildren(false);content.setClipToPadding(false);
   content.setPadding(0,dp(92),0,dp(70));mainScroll.addView(content);
   LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
   top.setPadding(dp(54),dp(6),dp(54),0);
   top.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0xf20a0712,0x000a0712}));
   root.addView(top,new FrameLayout.LayoutParams(-1,dp(96),Gravity.TOP));
   TextView brand=text("MIRACULOUS",22,true,Color.WHITE);brand.setLetterSpacing(0.08f);top.addView(brand);
   TextView hub=text("HUB",22,true,PINK);hub.setLetterSpacing(0.08f);addGap(top,hub,8);
   View gap=new View(this);top.addView(gap,new LinearLayout.LayoutParams(dp(36),dp(1)));
   for(String[] entry:new String[][]{{"Home","Home"},{"Series","Episodes"},{"Anime","Anime"},{"Upcoming","Upcoming"},{"Trailers","Trailers"},{"Live","Live"},{"My list","Continue"}}){
     final String target=entry[1];final boolean active=target.equals(page);
     TextView nav=text(entry[0],16,true,active?Color.WHITE:MUTED);
     nav.setGravity(Gravity.CENTER);nav.setFocusable(true);nav.setClickable(true);
     nav.setPadding(dp(20),0,dp(20),0);nav.setBackground(bg(active?0x33ff2d55:0x00000000,24));
     LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-2,dp(44));np.rightMargin=dp(6);top.addView(nav,np);
     nav.setOnFocusChangeListener((v,f)->{
       nav.setBackground(bg(f?0xfff6f3ff:active?0x33ff2d55:0x00000000,24));
       nav.setTextColor(f?0xff120d20:active?Color.WHITE:MUTED);
       nav.animate().scaleX(f?1.08f:1).scaleY(f?1.08f:1).setDuration(120).start();
     });
     nav.setOnClickListener(v->{page=target;if(!"Anime".equals(page))selectedAnime="";render();});
   }
   View flex=new View(this);top.addView(flex,new LinearLayout.LayoutParams(0,dp(1),1));
   TextView account=text(TvFirebase.auth(this).getCurrentUser()==null?"Sign in":"Account",15,true,Color.WHITE);
   account.setGravity(Gravity.CENTER);account.setFocusable(true);account.setClickable(true);
   account.setPadding(dp(22),0,dp(22),0);account.setBackground(bg(0xff2a2142,22));
   top.addView(account,new LinearLayout.LayoutParams(-2,dp(42)));
   account.setOnFocusChangeListener((v,f)->{
     account.setBackground(bg(f?0xff6a54a0:0xff2a2142,22));
     account.animate().scaleX(f?1.08f:1).scaleY(f?1.08f:1).setDuration(120).start();
   });
   account.setOnClickListener(v->startActivity(new Intent(this,AccountActivity.class)));
   if(onHome)home();else if("Episodes".equals(page))allEpisodes();
   else if("Upcoming".equals(page))upcoming();
   else if("Anime".equals(page))anime();else if("Trailers".equals(page))trailers();
   else if("Continue".equals(page))continueWatching();else if("Live".equals(page))livePage();else home();
   immersive();
 }
 private void title(String heading,String subtitle){
   TextView h=text(heading,34,true);h.setPadding(dp(58),dp(10),dp(58),0);content.addView(h);
   if(subtitle!=null){TextView s=text(subtitle,16,false,MUTED);s.setPadding(dp(58),dp(6),dp(58),0);content.addView(s);}
 }
 private void home(){
   LinearLayout stage=vertical();stage.setGravity(Gravity.BOTTOM);stage.setPadding(dp(58),0,dp(58),dp(28));
   content.addView(stage,new LinearLayout.LayoutParams(-1,dp(320)));
   ArrayList<JSONObject> newest=latest(1);
   if(!newest.isEmpty())heroItem=newest.get(0);
   heroKicker=text(heroItem==null?"NOW STREAMING":metaFor(heroItem),12,true,0xffff6b8a);
   heroKicker.setLetterSpacing(0.16f);stage.addView(heroKicker);
   heroTitle=text(heroItem==null?"Miraculous":heroItem.optString("title","Miraculous"),46,true,Color.WHITE);
   heroTitle.setMaxLines(2);heroTitle.setEllipsize(TextUtils.TruncateAt.END);
   LinearLayout.LayoutParams htp=new LinearLayout.LayoutParams(dp(680),-2);htp.topMargin=dp(6);stage.addView(heroTitle,htp);
   heroMeta=text("Miraculous: Tales of Ladybug & Cat Noir",17,false,0xffd9d6ea);stage.addView(heroMeta);
   space(stage,20);
   LinearLayout buttons=new LinearLayout(this);stage.addView(buttons);
   buttons.addView(pill("▶   Play",18,true,()->{if(heroItem!=null)open(heroItem);else{page="Episodes";render();}}));
   String recent=getPreferences(0).getString("recentTitle","");
   String recentUrl=getPreferences(0).getString("recentUrl","");
   if(!recent.isEmpty()&&recentUrl.startsWith("https://")){
     addGap(buttons,pill("↺   Resume",18,false,()->launch(recentUrl,recent)),14);
   }
   addGap(buttons,pill("All episodes",18,false,()->{page="Episodes";render();}),14);
   addGap(buttons,pill("●  Live",18,false,()->startActivity(new Intent(this,LiveActivity.class))),14);
   if(heroItem!=null)artwork(heroImg,thumb(heroItem));
   homeContinueRail();
   rows("Season 7",bySeason(7));
   rows("Recently added",latest(18));
   animeStrip();
   rows("Trailers and previews",new ArrayList<>(trailers));
 }
 private void livePage(){
   title("Live","Watch the MiraculousHub stream and release countdowns.");space(content,26);
   LinearLayout actions=new LinearLayout(this);actions.setPadding(dp(58),0,dp(58),0);content.addView(actions);
   actions.addView(pill("▶   Open live stream",20,true,()->startActivity(new Intent(this,LiveActivity.class))));
   addGap(actions,pill("Release countdowns",20,false,()->{
     Intent i=new Intent(this,LiveActivity.class);i.putExtra("pageUrl","https://miraculoushub.co.uk/#upcoming-releases");startActivity(i);
   }),16);
 }
 private void upcoming(){
   title("Upcoming","Season 7 and the newest releases.");space(content,18);
   rows("Season 7",bySeason(7));
   rows("Recently added",latest(12));
 }
 private void seasonSelector(){
   HorizontalScrollView scroller=new HorizontalScrollView(this);scroller.setHorizontalScrollBarEnabled(false);
   scroller.setClipChildren(false);scroller.setClipToPadding(false);content.addView(scroller);
   LinearLayout lane=new LinearLayout(this);lane.setClipChildren(false);lane.setPadding(dp(58),dp(8),dp(58),dp(8));scroller.addView(lane);
   for(int season=7;season>=1;season--){
     final int chosen=season;final boolean on=chosen==selectedSeason;
     TextView chip=text("Season "+season,16,true,Color.WHITE);
     chip.setGravity(Gravity.CENTER);chip.setPadding(dp(24),dp(12),dp(24),dp(12));
     chip.setBackground(bg(on?PINK:0x552a2142,26));chip.setFocusable(true);chip.setClickable(true);
     addGap(lane,chip,0);
     ((LinearLayout.LayoutParams)chip.getLayoutParams()).rightMargin=dp(12);
     chip.setOnFocusChangeListener((v,f)->{
       chip.setBackground(bg(f?0xfff6f3ff:on?PINK:0x552a2142,26));
       chip.setTextColor(f?0xff120d20:Color.WHITE);
       chip.animate().scaleX(f?1.08f:1).scaleY(f?1.08f:1).setDuration(130).start();
       if(f)scroller.smoothScrollTo(Math.max(0,chip.getLeft()-dp(40)),0);
     });
     chip.setOnClickListener(v->{selectedSeason=chosen;page="Episodes";render();});
   }
 }
 private void allEpisodes(){
   title("Episodes","Choose a season, then press OK on any episode.");
   space(content,20);seasonSelector();space(content,14);
   ArrayList<JSONObject> list=bySeason(selectedSeason);
   if(list.isEmpty()){TextView none=text("No episodes uploaded for this season yet.",16,false,MUTED);none.setPadding(dp(58),dp(10),dp(58),0);content.addView(none);}
   else grid(content,list);
 }
 private void trailers(){
   title("Trailers and previews","First looks and uploaded trailers.");space(content,22);
   rows("Latest trailers",new ArrayList<>(trailers));
 }
 private void homeContinueRail(){
   FirebaseUser user=TvFirebase.auth(this).getCurrentUser();
   if(user==null)return;
   LinearLayout holder=vertical();holder.setClipChildren(false);content.addView(holder);
   TvFirebase.database(this).collection("users").document(user.getUid()).collection("playback")
     .orderBy("updatedAt",Query.Direction.DESCENDING).limit(15).get(Source.SERVER)
     .addOnCompleteListener(this,result->{
       if(!"Home".equals(page)||holder.getParent()==null||!result.isSuccessful())return;
       ArrayList<JSONObject> history=new ArrayList<>();
       for(DocumentSnapshot snap:result.getResult().getDocuments()){
         JSONObject item=findCloudEpisode(snap);if(item!=null)history.add(item);
       }
       if(history.isEmpty())return;
       holder.removeAllViews();
       TextView heading=text("Continue watching",22,true);heading.setPadding(dp(58),0,dp(58),0);holder.addView(heading);
       strip(holder,history);space(holder,18);
     });
 }
 private void continueWatching(){
   title("My list","Pick up where you left off on any device.");space(content,22);
   FirebaseUser account=TvFirebase.auth(this).getCurrentUser();
   if(account!=null){
     TextView syncing=text("Loading your watch history…",15,false,MUTED);syncing.setPadding(dp(58),0,dp(58),0);content.addView(syncing);
     LinearLayout holder=vertical();holder.setClipChildren(false);content.addView(holder);
     TvFirebase.database(this).collection("users").document(account.getUid())
       .collection("playback").orderBy("updatedAt",Query.Direction.DESCENDING).limit(25)
       .get(Source.SERVER).addOnCompleteListener(this,result->{
         if(!"Continue".equals(page)||holder.getParent()==null)return;
         syncing.setVisibility(View.GONE);holder.removeAllViews();
         ArrayList<JSONObject> list=new ArrayList<>();
         if(result.isSuccessful())for(DocumentSnapshot snap:result.getResult().getDocuments()){
           JSONObject episode=findCloudEpisode(snap);if(episode!=null)list.add(episode);
         }
         if(!result.isSuccessful()){
           TextView m=text("Couldn't reach your account. Try again in a moment.",16,false,MUTED);m.setPadding(dp(58),0,dp(58),0);holder.addView(m);
         }else if(list.isEmpty()){
           TextView m=text("No progress yet. Start an episode on the website or your phone.",16,false,MUTED);m.setPadding(dp(58),0,dp(58),0);holder.addView(m);
         }else grid(holder,list);
       });
   }else{
     TextView message=text("Sign in to sync your watch history across devices.",17,false,MUTED);
     message.setPadding(dp(58),0,dp(58),dp(14));content.addView(message);
     LinearLayout row=new LinearLayout(this);row.setPadding(dp(58),0,dp(58),0);content.addView(row);
     row.addView(pill("Sign in or pair with QR code",18,true,()->startActivity(new Intent(this,AccountActivity.class))));
   }
   String url=getPreferences(0).getString("recentUrl",""),label=getPreferences(0).getString("recentTitle","");
   if(url.isEmpty())return;
   space(content,26);
   TextView last=text("On this device",22,true);last.setPadding(dp(58),0,dp(58),dp(12));content.addView(last);
   LinearLayout row2=new LinearLayout(this);row2.setPadding(dp(58),0,dp(58),0);content.addView(row2);
   row2.addView(pill("▶   Resume  •  "+label,18,false,()->{
     Intent intent=new Intent(this,PlayerActivity.class);intent.putExtra("url",url);intent.putExtra("title",label);
     intent.putExtra("cloudKey",getPreferences(0).getString("recentKey",""));
     intent.putExtra("season",getPreferences(0).getInt("recentSeason",0));
     intent.putExtra("episode",getPreferences(0).getInt("recentEpisode",0));
     startActivity(intent);
   }));
 }
 private void rows(String heading,ArrayList<JSONObject> items){
   TextView title=text(heading,22,true);title.setPadding(dp(58),0,dp(58),0);content.addView(title);
   if(items.isEmpty()){
     TextView empty=text(catalogError.isEmpty()?"Nothing here yet.":"Couldn't load the live catalogue. Pull to refresh later.",14,false,MUTED);
     empty.setPadding(dp(58),dp(8),dp(58),0);content.addView(empty);space(content,24);return;
   }
   strip(content,items);space(content,18);
 }
 private void strip(ViewGroup parent,ArrayList<JSONObject> items){
   HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setHorizontalScrollBarEnabled(false);
   scroll.setClipChildren(false);scroll.setClipToPadding(false);parent.addView(scroll);
   LinearLayout lane=new LinearLayout(this);lane.setPadding(dp(58),dp(14),dp(58),dp(18));
   lane.setClipChildren(false);lane.setClipToPadding(false);scroll.addView(lane);
   int max=Math.min(items.size(),52);
   for(int i=0;i<max;i++)lane.addView(tile(items.get(i),scroll,dp(300),dp(169)));
 }
 private void grid(ViewGroup parent,ArrayList<JSONObject> items){
   int cols=3,gap=dp(18),w=(screenW()-dp(116)-gap*cols)/cols,h=w*9/16;
   LinearLayout line=null;
   for(int i=0;i<items.size();i++){
     if(i%cols==0){line=new LinearLayout(this);line.setClipChildren(false);line.setPadding(dp(58),dp(8),dp(58),dp(8));parent.addView(line);}
     line.addView(tile(items.get(i),null,w,h));
   }
 }
 private View episodeCard(JSONObject item,HorizontalScrollView scroll){return tile(item,scroll,dp(300),dp(169));}
 private View tile(JSONObject item,HorizontalScrollView scroll,int w,int h){
   String name=item.optString("title","Episode");
   boolean trailer="trailer".equals(item.optString("kind"));
   FrameLayout card=new FrameLayout(this);card.setBackground(bg(PANEL,14));card.setClipToOutline(true);
   card.setFocusable(true);card.setClickable(true);
   LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(w,h);cp.rightMargin=dp(18);card.setLayoutParams(cp);
   ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);
   card.addView(img,new FrameLayout.LayoutParams(-1,-1));artwork(img,thumb(item));
   View shade=new View(this);
   shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x000a0712,0xf00a0712}));
   card.addView(shade,new FrameLayout.LayoutParams(-1,(int)(h*0.7f),Gravity.BOTTOM));
   String tag=trailer?"TRAILER":item.optString("code","");
   if(!tag.isEmpty()){
     TextView chip=text(tag,11,true,Color.WHITE);chip.setPadding(dp(10),dp(4),dp(10),dp(4));chip.setBackground(bg(0xcc0a0712,10));
     FrameLayout.LayoutParams chipP=new FrameLayout.LayoutParams(-2,-2,Gravity.LEFT|Gravity.TOP);chipP.setMargins(dp(10),dp(10),0,0);card.addView(chip,chipP);
   }
   TextView label=text(name,16,true);label.setMaxLines(1);label.setEllipsize(TextUtils.TruncateAt.END);
   label.setPadding(dp(14),0,dp(14),dp(12));card.addView(label,new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM));
   TextView play=text("▶",18,true);play.setGravity(Gravity.CENTER);play.setBackground(bg(PINK,40));play.setAlpha(0f);
   card.addView(play,new FrameLayout.LayoutParams(dp(46),dp(46),Gravity.CENTER));
   card.setOnFocusChangeListener((v,f)->{
     card.setForeground(f?ring(14):null);
     card.setElevation(f?dp(14):0);
     card.animate().scaleX(f?1.1f:1).scaleY(f?1.1f:1).setDuration(150).start();
     play.animate().alpha(f?1f:0f).setDuration(150).start();
     if(f&&scroll!=null)scroll.smoothScrollTo(Math.max(0,card.getLeft()-dp(40)),0);
     if(f)setHero(item);
   });
   card.setOnClickListener(v->open(item));
   return card;
 }
 private void animeStrip(){
   TextView heading=text("Monthly anime",22,true);heading.setPadding(dp(58),0,dp(58),0);content.addView(heading);
   HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setHorizontalScrollBarEnabled(false);
   scroll.setClipChildren(false);scroll.setClipToPadding(false);content.addView(scroll);
   LinearLayout lane=new LinearLayout(this);lane.setPadding(dp(58),dp(14),dp(58),dp(18));lane.setClipChildren(false);lane.setClipToPadding(false);scroll.addView(lane);
   for(String[] show:shows())lane.addView(animeCard(show,scroll));
   space(content,18);
 }
 private View animeCard(String[] show,HorizontalScrollView scroll){
   FrameLayout card=new FrameLayout(this);card.setBackground(bg(PANEL,14));card.setClipToOutline(true);
   card.setFocusable(true);card.setClickable(true);
   LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(340),dp(190));p.rightMargin=dp(18);card.setLayoutParams(p);
   ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);
   card.addView(image,new FrameLayout.LayoutParams(-1,-1));artwork(image,cover(show[1]));
   View fade=new View(this);fade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x330a0712,0xf50a0712}));
   card.addView(fade,new FrameLayout.LayoutParams(-1,-1));
   LinearLayout info=vertical();info.setPadding(dp(16),0,dp(14),dp(14));
   card.addView(info,new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM));
   info.addView(text("MONTHLY COLLECTION",11,true,0xffff6b8a));
   info.addView(text(show[0],22,true));
   info.addView(text(show[2],13,false,MUTED));
   card.setOnFocusChangeListener((v,f)->{
     card.setForeground(f?ring(14):null);card.setElevation(f?dp(14):0);
     card.animate().scaleX(f?1.08f:1).scaleY(f?1.08f:1).setDuration(150).start();
     if(f)scroll.smoothScrollTo(Math.max(0,card.getLeft()-dp(40)),0);
   });
   card.setOnClickListener(v->{selectedAnime=show[1];page="Anime";render();});
   return card;
 }
 private void anime(){
   if(selectedAnime.isEmpty()){
     title("Monthly anime","Death Note, Attack on Titan and Black Clover.");space(content,22);animeStrip();return;
   }
   String name=selectedAnime.equals("death-note")?"Death Note":selectedAnime.equals("attack-on-titan")?"Attack on Titan":"Black Clover";
   LinearLayout backRow=new LinearLayout(this);backRow.setPadding(dp(58),dp(6),dp(58),dp(10));content.addView(backRow);
   backRow.addView(pill("‹   All anime",15,false,()->{selectedAnime="";render();}));
   title(name,"Select an episode to start playback.");space(content,18);
   int count=selectedAnime.equals("death-note")?37:selectedAnime.equals("attack-on-titan")?94:170;
   for(int start=1;start<=count;start+=24){
     ArrayList<JSONObject> batch=new ArrayList<>();
     int end=Math.min(count,start+23);
     for(int n=start;n<=end;n++){
       try{
         JSONObject e=new JSONObject();e.put("title",name+" • Episode "+n);
         e.put("code","EP "+n);e.put("thumbnail",cover(selectedAnime));
         String no=String.format(Locale.US,selectedAnime.equals("black-clover")?"%03d":"%02d",n);
         e.put("videoPath","/video/anime/"+selectedAnime+"/e"+no);
         batch.add(e);
       }catch(Exception ignored){}
     }
     rows("Episodes "+start+"–"+end,batch);
   }
 }
 private ArrayList<JSONObject> latest(int count){
   ArrayList<JSONObject> all=new ArrayList<>(episodes);Collections.reverse(all);
   if(all.size()>count)return new ArrayList<>(all.subList(0,count));return all;
 }
 private ArrayList<JSONObject> bySeason(int season){
   ArrayList<JSONObject> all=new ArrayList<>();
   for(JSONObject x:episodes)if(x.optInt("season")==season)all.add(x);
   return all;
 }
 private JSONObject findCloudEpisode(DocumentSnapshot doc){
   String key=doc.getId(),title=doc.getString("title");
   try{
     if(key.matches("s[0-9]+e[0-9]+")){
       int delimiter=key.indexOf('e'),season=Integer.parseInt(key.substring(1,delimiter)),episode=Integer.parseInt(key.substring(delimiter+1));
       for(JSONObject e:episodes)if(e.optInt("season")==season&&e.optInt("episode")==episode)return e;
       JSONObject item=new JSONObject();
       String code=String.format(Locale.US,"S%02dE%02d",season,episode);
       item.put("season",season);item.put("episode",episode);item.put("code",code);
       item.put("title",title==null?"Episode "+episode:title);
       item.put("videoPath","/video/"+code.toLowerCase(Locale.US));return item;
     }
     if(key.matches("anime-[a-z0-9-]+-e[0-9]+")){
       int delimiter=key.lastIndexOf("-e");String slug=key.substring(6,delimiter);
       int episode=Integer.parseInt(key.substring(delimiter+2));
       JSONObject item=new JSONObject();item.put("title",title==null?"Anime episode "+episode:title);
       item.put("code","EP "+episode);item.put("thumbnail",cover(slug));
       item.put("videoPath","/video/anime/"+slug+"/e"+String.format(Locale.US,"black-clover".equals(slug)?"%03d":"%02d",episode));
       return item;
     }
   }catch(Exception ignored){}
   return null;
 }
 private String[][] shows(){return new String[][]{{"Death Note","death-note","37 episodes"},{"Attack on Titan","attack-on-titan","94 episodes"},{"Black Clover","black-clover","170 episodes"}};}
 private String cover(String slug){
   if("death-note".equals(slug))return "https://cdn.myanimelist.net/images/anime/1079/138100.jpg";
   if("attack-on-titan".equals(slug))return "https://cdn.myanimelist.net/images/anime/10/47347.jpg";
   return "https://cdn.myanimelist.net/images/anime/2/88336.jpg";
 }
 private void focus(View item,boolean focused,int on,int off){
   item.setBackground(bg(focused?on:off,16));
   item.animate().scaleX(focused?1.045f:1).scaleY(focused?1.045f:1).setDuration(135).start();
 }
 private String cloudKeyForItem(JSONObject item){
   int season=item.optInt("season"),episode=item.optInt("episode");
   if(season>0&&episode>0)return "s"+season+"e"+episode;
   String path=item.optString("videoPath","");
   if(path.startsWith("/video/anime/")){
     String[] parts=path.split("/");
     if(parts.length==5&&parts[4].matches("e[0-9]{1,3}")){
       try{return "anime-"+parts[3]+"-e"+Integer.parseInt(parts[4].substring(1));}
       catch(Exception ignored){}
     }
   }
   return "";
 }
 private void launch(String url,String title){launch(url,title,null);}
 private void launch(String url,String title,JSONObject item){
   if(!url.startsWith("https://"))return;
   Intent intent=new Intent(this,PlayerActivity.class);intent.putExtra("url",url);intent.putExtra("title",title);
   if(item!=null){
     int season=item.optInt("season"),episode=item.optInt("episode");
     String path=item.optString("videoPath");
     if(season>0&&episode>0)intent.putExtra("cloudKey","s"+season+"e"+episode);
     else if(path.startsWith("/video/anime/")){
       String[] parts=path.split("/");
       if(parts.length==5){String slug=parts[3],e=parts[4];try{
         int number=Integer.parseInt(e.substring(1));
         intent.putExtra("cloudKey","anime-"+slug+"-e"+number);
       }catch(Exception ignored){}}
     }
     intent.putExtra("season",season);intent.putExtra("episode",episode);
   }
   JSONArray library=new JSONArray();
   for(JSONObject e:episodes){int season=e.optInt("season"),episode=e.optInt("episode");String path=e.optString("videoPath","");
     if(season<=0||episode<=0||!path.startsWith("/video/"))continue;
     JSONObject row=new JSONObject();try{row.put("season",season);row.put("episode",episode);row.put("title",e.optString("title","Episode"));row.put("path",path);library.put(row);}catch(JSONException ignored){}
   }
   intent.putExtra("episodeLibrary",library.toString());
   startActivity(intent);
 }
 private void checkAppUpdates(){checkAppUpdates(false);}
 private void checkAppUpdates(boolean manual){
   lastUpdateCheck=System.currentTimeMillis();
   AppUpdater.check(this,manual);
 }
 @Override protected void onPause(){handler.removeCallbacks(liveRefresh);super.onPause();}
 @Override public void onBackPressed(){
   if("Anime".equals(page)&&!selectedAnime.isEmpty()){selectedAnime="";render();}
   else if(!"Home".equals(page)){page="Home";render();}
   else super.onBackPressed();
 }
 @Override protected void onResume(){
   super.onResume();immersive();AppUpdater.onResume(this);
   if(System.currentTimeMillis()-lastUpdateCheck>15*60*1000)checkAppUpdates();
   handler.removeCallbacks(liveRefresh);handler.postDelayed(liveRefresh,120000);
   if(System.currentTimeMillis()-lastLibrarySync>120000)refresh();
   if("Continue".equals(page)&&content!=null)render();
 }
}
